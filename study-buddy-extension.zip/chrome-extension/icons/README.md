# Extension Icons

Place your extension icons here:

- `icon-16.png` - 16x16 pixels
- `icon-48.png` - 48x48 pixels  
- `icon-128.png` - 128x128 pixels

You can use the Study Buddy logo/icon from your assets folder and resize it to these dimensions.

For now, you can create placeholder icons or use any image editor to create them.

